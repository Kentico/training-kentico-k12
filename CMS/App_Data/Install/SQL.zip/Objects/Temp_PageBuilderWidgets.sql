SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Temp_PageBuilderWidgets](
	[PageBuilderWidgetsID] [int] IDENTITY(1,1) NOT NULL,
	[PageBuilderWidgetsConfiguration] [nvarchar](max) NULL,
	[PageBuilderWidgetsGuid] [uniqueidentifier] NOT NULL,
	[PageBuilderWidgetsLastModified] [datetime2](7) NOT NULL,
	[PageBuilderTemplateConfiguration] [nvarchar](max) NULL,
 CONSTRAINT [PK_Temp_PageBuilderWidgets] PRIMARY KEY CLUSTERED 
(
	[PageBuilderWidgetsID] ASC
)
)

GO
ALTER TABLE [dbo].[Temp_PageBuilderWidgets] ADD  CONSTRAINT [DEFAULT_Temp_PageBuilderWidgets_PageBuilderWidgetsGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [PageBuilderWidgetsGuid]
GO
ALTER TABLE [dbo].[Temp_PageBuilderWidgets] ADD  CONSTRAINT [DEFAULT_Temp_PageBuilderWidgets_PageBuilderWidgetsLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [PageBuilderWidgetsLastModified]
GO
